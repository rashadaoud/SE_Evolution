package smallsql.database;
import java.io.*;

class Column {
	int method(){
		int a = 2;
		int b;
		int c;
		return a;
	}
}
